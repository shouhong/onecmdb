Readme Linux

$Id: readme_linux.txt,v 1.1 2004/06/19 14:01:56 fredt Exp $
Query CVS for revision history.

It is recommended to run the shell scripts(from /bin and /demo) from the 
console, as you will not to be able see any messages from the desktop.
You should set the env variable $JAVA_HOME before running any of the sripts,
or you can use the -jdkhome switch instead to specify the JDK.

See the UNIX Quick Start chapter of the Hsqldb User Guide about how to use
the UNIX init script 'hsqldb'.
